import { Object3D } from "three";
export declare function replaceBrushMaterials(brushPath: string, model: Object3D): Promise<void>;
